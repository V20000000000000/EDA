// Description: main function for the project

#include <iostream>
#include <fstream>
#include <vector>

#include "InputDataParse.hpp"

int main()
{
    InputDataParse idp("case4");
    idp.parseBlkData("case4");
    return 0;
}

