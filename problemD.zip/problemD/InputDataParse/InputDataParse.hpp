// InputDataParse class definition 
// Parsing blk data from /testcase/caseX/caseX_def/blk_id.def and caseX_cfg.json
// Parsing net data from /testcase/caseX/caseX_def/net_id.def and caseX.json
// class input: caseX   

#ifndef INPUT_DATA_PARSE_HPP
#define INPUT_DATA_PARSE_HPP

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <utility> // for std::pair
#include <filesystem>
#include "include\nlohmann\json.hpp"

#include "Blk.hpp"
#include "Net.hpp"
#include "Region.hpp"

using namespace std;

bool fileExistsInDirectory(const std::string& directory, const std::string& filename);

class InputDataParse
{
    private:
        string case_name;
        vector<Blk> allBlocks;
        vector<Net> allNets;
        vector<Region> allRegions;

    public:
        InputDataParse(const string &case_name) : case_name(case_name) {}

        void parseBlkData(string case_name)
        {
            // read mutiline blk_id.def from file
            int i = 0;
            string directory = "testcase/" + case_name + "/" + case_name + "_def/";
            string filename = "blk_" + to_string(i) + ".def";
            while (fileExistsInDirectory(directory, filename))
            {
                ifstream file(directory + filename);
                cout << "Reading " << filename << endl;
                i++;
                filename = "blk_" + to_string(i) + ".def";
            }

        }
        // void parseNetData();
        // void parseRegionData();
        // void printBlkData();
        // void printNetData();
        // void printRegionData();
        // vector<Blk> getAllBlocks() const;
        // vector<Net> getAllNets() const;
        // vector<Region> getAllRegions() const;
};

bool fileExistsInDirectory(const std::string& directory, const std::string& filename) {
    std::filesystem::path dirPath(directory);
    std::filesystem::path filePath = dirPath / filename;

    return std::filesystem::exists(filePath);
}

#endif